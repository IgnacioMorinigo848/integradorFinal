
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class ConexionBD {
    private static final String URL = "jdbc:mysql://localhost:3306/cuentas";
     private static final String USER = "root";
     private static final String PASS = "123456789";
     
      static {
        try {
            // Registra el controlador JDBC (opcional a partir de JDBC 4.0)
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            // Mejor manejo de la excepciÃ³n, lanzando una excepciÃ³n de inicializaciÃ³n
            throw new RuntimeException("Error al cargar el controlador JDBC", e);
        }
    }
     
     public static Connection conectar() throws SQLException{
        return DriverManager.getConnection(URL,USER,PASS);
     }
}
