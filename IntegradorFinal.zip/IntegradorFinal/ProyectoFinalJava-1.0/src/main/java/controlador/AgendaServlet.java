package controlador;

import crud.CrudImplementacion;
import crud.CrudInterfaz;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Contacto;

//anotaciones = nos permiten definir cosas
//definir este archivo como un servlet y establece la URL a la que respondera
@WebServlet(name = "AgendaServlet", urlPatterns = {"/AgendaServlet"})
public class AgendaServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Recoge los datos del formulario
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String email = request.getParameter("email");
        String contraseña = request.getParameter("contra");
        String rol = request.getParameter("rol");

        // Crea un nuevo contacto con los datos recogidos
        Contacto nuevoContacto = new Contacto();
        nuevoContacto.setNombre(nombre);
        nuevoContacto.setApellido(apellido);
        nuevoContacto.setEmail(email);
        nuevoContacto.setContraseña(contraseña);
        nuevoContacto.setRol(rol);

        // Añade el nuevo contacto a la lista
        CrudInterfaz cd = new CrudImplementacion();
        cd.agregar(nuevoContacto);

        // Redirige de nuevo al JSP
        if (cd.leer().size() == 1) {
            response.sendRedirect(request.getContextPath() + "index.jsp");
        } else {
            response.sendRedirect(request.getContextPath() + "CrearCuenta.jsp");
        }
    }

}
