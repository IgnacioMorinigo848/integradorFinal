package controlador;

import conexion.ConexionBD;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "OlvidoContraseña", urlPatterns = {"/OlvidoContraseña"})
public class OlvidoContraseña extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String email = request.getParameter("email");
        
        if(existeUsuario(id,email)){
             request.setAttribute("id", id);
             request.getRequestDispatcher("RecuperarContra.jsp").forward(request, response);
        }else{
            response.sendRedirect("OlvidoContra.jsp");
        }

    }

    public boolean existeUsuario(int id, String email){
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String rol = "";

        try {
            conn = ConexionBD.conectar();
            String sql = "SELECT * FROM cuenta WHERE id = ? AND email = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            pstmt.setString(2, email);

            rs = pstmt.executeQuery();
            
              return rs.next();

        } catch (SQLException e) {
            e.printStackTrace();
             return false;
        }
    }

}
