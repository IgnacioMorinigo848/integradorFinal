package controlador;

import conexion.ConexionBD;
import crud.CrudImplementacion;
import crud.CrudInterfaz;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Contacto;

// Anotación que define este archivo como un Servlet y establece la URL a la que responderá.
@WebServlet(name = "OperacionServlet", urlPatterns = {"/OperacionServlet"})
public class OperacionServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String accion = request.getParameter("accion");
        String idParam = request.getParameter("id");
        int id = 0;
        if (idParam != null && !idParam.isEmpty()) {

            id = Integer.parseInt(idParam);
        }
        CrudInterfaz cd = new CrudImplementacion();
        // Usamos un switch para manejar las diferentes acciones.

        switch (accion) {
            case "eliminar":
                // Si la acción es "eliminar", obtenemos el índice del contacto y lo eliminamos de la lista.
                cd.eliminar(id);
                // Redirigimos al usuario de vuelta a la página principal.
                response.sendRedirect("CrearCuenta.jsp");
                break;
            case "actualizar":
                String nombre = request.getParameter("nombre");
                String apellido = request.getParameter("apellido");
                String email = request.getParameter("email");
                String contraseña = request.getParameter("contra");
                String rol = request.getParameter("rol");

                Contacto contactoActualizado = new Contacto();
                contactoActualizado.setIdContacto(id);
                contactoActualizado.setNombre(nombre);
                contactoActualizado.setApellido(apellido);
                contactoActualizado.setEmail(email);
                contactoActualizado.setContraseña(contraseña);
                contactoActualizado.setRol(rol);

                cd.actualizar(contactoActualizado);

                // Redirigir al usuario a la página principal después de actualizar
                response.sendRedirect("CrearCuenta.jsp");
                break;

            // ...
            case "editar":
                Contacto contactoAEditar = cd.obtenerPorId(id);
                request.setAttribute("contactoAEditar", contactoAEditar);
                request.getRequestDispatcher("editar.jsp").forward(request, response);
                break;

            case "IniciarS":
                response.sendRedirect("index.jsp");
                break;
            case "CrearCuenta":
                response.sendRedirect("CrearCuenta.jsp");
                break;
        }
    }

}
