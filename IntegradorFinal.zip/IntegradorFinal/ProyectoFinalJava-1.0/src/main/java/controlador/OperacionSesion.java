package controlador;

import conexion.ConexionBD;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import modelo.Contacto;

@WebServlet(name = "OperacionSesion", urlPatterns = {"/OperacionSesion"})
public class OperacionSesion extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String contraseña = request.getParameter("contra");

        if (autenticarUsuario(email, contraseña)) {
            HttpSession session = request.getSession();
            String rol = tipoUsuario(email, contraseña);

            // Usuario autenticado con éxito
            if ("Administrador".equalsIgnoreCase(rol)) {
                session.setAttribute("email", email);
                logeado(email, contraseña);
                response.sendRedirect("CrearCuenta.jsp");

            } else {
                session.setAttribute("email", email);
                logeado(email, contraseña);
                response.sendRedirect("VerUsuario.jsp");
            }

        } else {
            // Autenticación fallida
            request.setAttribute("error", "Nombre de usuario o contraseña inválidos.");
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }

    }

    private boolean autenticarUsuario(String email, String contraseña) {
        // Aquí va la lógica para conectarse a la base de datos y verificar las credenciales
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        // cerrando los recursos manualmente
        try {
            conn = ConexionBD.conectar(); // Asume que tienes un método estático getConnection en tu clase Conexion
            String sql = "SELECT * FROM cuenta WHERE email = ? AND contraseña = ?"; // Asegúrate de que esta consulta coincida con tu esquema de base de datos
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, email);
            pstmt.setString(2, contraseña);

            rs = pstmt.executeQuery();

            return rs.next(); // Si hay un resultado, las credenciales son correctas
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            // Cerrar recursos
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public String tipoUsuario(String email, String contraseña) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String rol = "";

        try {
            conn = ConexionBD.conectar();
            String sql = "SELECT rol FROM cuenta WHERE email = ? AND contraseña = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, email);
            pstmt.setString(2, contraseña);

            rs = pstmt.executeQuery();

            if (rs.next()) {
                rol = rs.getString("rol");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Cerrar recursos
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return rol;
    }

    public void logeado(String email, String contraseña) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Contacto c = new Contacto();

        try {
            conn = ConexionBD.conectar();
            String sql = "SELECT nombre,apellido FROM cuenta WHERE email = ? AND contraseña = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, email);
            pstmt.setString(2, contraseña);

            rs = pstmt.executeQuery();

            if (rs.next()) {
                c.setNombre(rs.getString("nombre"));
                c.setApellido(rs.getString("apellido"));
                c.setEmail(email);
            }
           
        } catch (SQLException e) {
            e.printStackTrace();

        }
         guardarLogeo(c);
    }

    public void guardarLogeo(Contacto c) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = ConexionBD.conectar();
            String sql = "INSERT INTO log (nombre,apellido,email) values(?,?,?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, c.getNombre());
            pstmt.setString(2, c.getApellido());
            pstmt.setString(3, c.getEmail());
            pstmt.executeUpdate();
        } catch (SQLException e) {

        }
    }

    public Contacto logPermanente() {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Contacto c = new Contacto();
        String sql = "SELECT * FROM log";
        try {
            conn = ConexionBD.conectar();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                c.setNombre(rs.getString("nombre"));
                c.setApellido(rs.getString("apellido"));
                c.setEmail(rs.getString("email"));
            }
        } catch (SQLException e) {

        }
        return c;
    }

}
