package controlador;

import conexion.ConexionBD;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "RecuperarContraseña", urlPatterns = {"/RecuperarContraseña"})
public class RecuperarContraseña extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String contraseña = request.getParameter("contra");
        String contraseña2 = request.getParameter("contra2");
        if(contraseña.equals(contraseña2)){
        actualizarContraseña(id,contraseña);
        response.sendRedirect("index.jsp");
        }else{
             response.sendRedirect("OlvidoContra.jsp");
        }
    }
    public void actualizarContraseña(int id,String contraseña){
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = ConexionBD.conectar();
            String sql = "UPDATE cuenta SET contraseña = ? WHERE id = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, contraseña);
            pstmt.setInt(2, id);
            
            pstmt.executeUpdate();
            
         } catch (SQLException e) {
            e.printStackTrace();
        }

    
    
    }

    }
