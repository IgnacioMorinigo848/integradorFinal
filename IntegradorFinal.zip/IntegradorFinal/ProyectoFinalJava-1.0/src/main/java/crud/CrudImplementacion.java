package crud;

import conexion.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Contacto;

public class CrudImplementacion implements CrudInterfaz {

    public void agregar(Contacto contacto) {
        String SQL = "INSERT INTO cuenta (nombre,apellido,email,contraseña,rol) VALUES (?,?,?,?,?)";
        try ( Connection conn = ConexionBD.conectar();  PreparedStatement pstmt = conn.prepareStatement(SQL)) {
            pstmt.setString(1, contacto.getNombre());
            pstmt.setString(2, contacto.getApellido());
            pstmt.setString(3, contacto.getEmail());
            pstmt.setString(4, contacto.getContraseña());
            pstmt.setString(5, contacto.getRol());

            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public List<Contacto> leer() {
        List<Contacto> contactos = new ArrayList<Contacto>();
        String SQL = "SELECT * FROM cuenta";
        try ( Connection conn = ConexionBD.conectar();  PreparedStatement pstmt = conn.prepareStatement(SQL)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Contacto c = new Contacto();
                c.setIdContacto(rs.getInt("id"));
                c.setNombre(rs.getString("nombre"));
                c.setApellido(rs.getString("apellido"));
                c.setEmail(rs.getString("email"));
                c.setContraseña(rs.getString("contraseña"));
                c.setRol(rs.getString("rol"));
                contactos.add(c);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return contactos;
    }

    public void actualizar(Contacto contacto) {
        String SQL = "UPDATE cuenta SET nombre = ?,apellido = ?, email = ?, contraseña = ?,rol = ? where id = ? ";
        try ( Connection conn = ConexionBD.conectar();  PreparedStatement pstmt = conn.prepareStatement(SQL)) {

            pstmt.setString(1, contacto.getNombre());
            pstmt.setString(2, contacto.getApellido());
            pstmt.setString(3, contacto.getEmail());
            pstmt.setString(4, contacto.getContraseña());
            pstmt.setString(5, contacto.getRol());
            pstmt.setInt(6, contacto.getIdContacto());

            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void eliminar(int id) {
        String SQL = "DELETE FROM cuenta WHERE id = ? ";
        try ( Connection conn = ConexionBD.conectar();  PreparedStatement pstmt = conn.prepareStatement(SQL)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public Contacto obtenerPorId(int id) {
        Contacto c = new Contacto();
        String SQL = "SELECT * FROM cuenta WHERE id = ? ";
        try ( Connection conn = ConexionBD.conectar();  PreparedStatement pstmt = conn.prepareStatement(SQL)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                c.setNombre(rs.getString("nombre"));
                c.setApellido(rs.getString("apellido"));
                c.setEmail(rs.getString("email"));
                c.setContraseña(rs.getString("contraseña"));
                c.setRol(rs.getString("rol"));

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return c;

    }


}
