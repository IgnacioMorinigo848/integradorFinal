
package crud;

import java.util.List;
import modelo.Contacto;

public interface CrudInterfaz {
    void agregar(Contacto contacto);
    List<Contacto> leer();
    void actualizar(Contacto contacto);
    void eliminar(int id);
    Contacto obtenerPorId(int id);  
}
