create database cuentas;

use cuentas;

create table cuenta(
	id int primary key auto_increment,
    nombre varchar(250) not null,
    apellido varchar(250) not null,
    email varchar(250) not null,
    contraseña varchar(250) not null,
    rol varchar(250) not null
);
create table log(
	nombre varchar(250),
    apellido varchar(250),
    email varchar(250)
);

